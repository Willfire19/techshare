$(document).ready(function() {
	$(".availability:contains('Available')").addClass('availability-Available');
	$(".availability:contains('Unavailable')").addClass('availability-Unavailable');
});
